# FPS Booster Lite (Fabric 1.21.11)

A small client-side mod starter project for Minecraft Java Edition 1.21.11. Press **O** to apply a lighter graphics profile:

- Render distance: 6 chunks
- Simulation distance: 4 chunks
- Particles: minimal
- Clouds: off
- Biome blend radius: 0
- Entity distance scaling: 50%
- VSync: off
- FPS limit: 120

## Important

This changes graphics options to reduce rendering load; FPS gains depend on the phone, GPU, drivers, shaders, and world. The toggle currently applies the profile when enabled and does not automatically restore prior settings when disabled. Adjust the settings manually after toggling off.

## Build the JAR

Requires JDK 21 and Gradle. From this project folder run:

```bash
gradle build
```

The remapped mod JAR should be in `build/libs/`.

## Install

Copy the built `fpsboosterlite-1.0.0.jar` into the `mods` folder used by your Mojo Launcher Fabric 1.21.11 instance. Fabric API must also be installed. Test on a copy of your world first.

This source is a starter project and has not been compiled or tested in Minecraft in this environment; API names may need adjustment if the selected Yarn/Fabric versions differ.
