package com.rhey.fpsbooster;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Lightweight client-side profile toggle. It only changes Minecraft graphics options;
 * it does not overclock hardware or guarantee a particular FPS increase.
 */
public final class FPSBoosterClient implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static boolean enabled = false;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.fpsboosterlite.toggle",
                GLFW.GLFW_KEY_O,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                applyProfile(client, enabled);
                if (client.player != null) {
                    client.player.sendMessage(Text.literal(enabled
                            ? "FPS Booster Lite: ON (lower graphics load)"
                            : "FPS Booster Lite: OFF (settings not automatically restored)"), false);
                }
            }
        });
    }

    private static void applyProfile(MinecraftClient client, boolean boost) {
        if (client == null) return;
        var options = client.options;
        if (boost) {
            options.getViewDistance().setValue(6);
            options.getSimulationDistance().setValue(4);
            options.getParticles().setValue(net.minecraft.particle.ParticleStatus.MINIMAL);
            options.getClouds().setValue(net.minecraft.client.option.CloudRenderMode.OFF);
            options.getBiomeBlendRadius().setValue(0);
            options.getEntityDistanceScaling().setValue(0.5);
            options.getEnableVsync().setValue(false);
            options.getMaxFps().setValue(120);
        }
    }
}
